import sys
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QDialog, QApplication, QMainWindow, QMessageBox, QStackedWidget
from PyQt5.QtChart import QChart, QChartView, QPieSeries, QCategoryAxis, QLineSeries
from PyQt5.QtCore import QPoint, QSize
from PyQt5.uic import loadUi
from PyQt5.QtCore import QDate, Qt
import mysql.connector


#=====Added module=====
import datetime
import pygrowup
from pygrowup import Calculator
from pygrowup import helpers

SYSTEM_NAME = "PPMS"

conn = mysql.connector.connect(host = 'localhost', user = 'root', password = 'admin', database = 'ppms', port=3306)
cursor = conn.cursor(dictionary=True, buffered=True)

def msgBox(title, content, iconType):
    msg = QtWidgets.QMessageBox()
    msg.setIcon(iconType)
    msg.setWindowTitle(title)
    msg.setText(content)
    msg.exec_()

#Set some QLine Edit to Characters only     
regex = QtCore.QRegExp("[a-z-A-Z_\s?]+")
validator = QtGui.QRegExpValidator(regex)

itsOkToClose = False

# Logged User (None means no user is logged in)
currentUser = None

Genderx = ['Male', 'Female']

COLOR_ORANGE = QtGui.QColor(242, 98, 33)
COLOR_GREEN = QtGui.QColor(0, 165, 79)
COLOR_YELLOW = QtGui.QColor(245, 241, 1)
COLOR_RED = QtGui.QColor(238, 29, 35)
COLOR_GRAY = QtGui.QColor(71, 71, 71)

calculator = Calculator(adjust_height_data=False, adjust_weight_scores=False,
                        include_cdc=False, logger_name='pygrowup',
                        log_level='INFO')

class BNS:
    def __init__(self, idBNS):
        self.id = idBNS
    def get(self, key):
        cursor.execute('SELECT ' + key + ' FROM bns WHERE idBNS=' + str(self.id))
        result = cursor.fetchone()
        return result.get(key)
    @staticmethod
    def add(data = {}):
        cursor.execute("INSERT INTO bns(firstName, lastName, email, password, isVerified) VALUES(%s, %s, %s, %s, %s)", (
            data.get('firstName'), data.get('lastName'), data.get('email'), data.get('password'), data.get('isVerified')
        ))
        conn.commit()

class Preschooler:
    def __init__(self, idPreschooler):
        self.id = idPreschooler
        self.firstName = self.get('firstName')
        self.lastName = self.get('lastName')
        self.birthdate = self.get('birthdate')
        self.gender = self.get('gender')
    def get(self, key):
        cursor.execute('SELECT ' + key + ' FROM preschooler WHERE idPreschooler=' + str(self.id))
        result = cursor.fetchone()
        return result.get(key)
    def ageInMonths(self, measured):
        dateFormat = "%Y-%m-%d"
        birthDate = datetime.datetime.strptime(str(self.birthdate), dateFormat)
        dateMeasured = datetime.datetime.strptime(str(measured), dateFormat)
        return int((dateMeasured.year - birthDate.year) * 12 + (dateMeasured.month - birthDate.month))
    def calculate(self, data):   
        try:     
            gender = helpers.get_good_sex(self.gender)
            age = self.ageInMonths(data.get('dateMeasured'))
            height, weight = float(data.get('height')), float(data.get('weight'))

            result = {
                'wfa': calculator.wfa(weight, age, gender),
                'hfa': calculator.lhfa(height, age, gender),
                'whfa': calculator.wfl(weight, age, gender, height)
            }
            return result['wfa'], result['hfa'], result['whfa']
        except:
            return 0, 0, 0

    def getTag(self, dateMeasured, score):
        if self.ageInMonths(dateMeasured) < 60:
            if score > +2.0:
                return 'ABOVE_NORMAL'
            elif -2.0 <= score <= +2.0:
                return 'NORMAL'
            elif -3.0 <= score < -2.0:
                return 'BELOW_NORMAL'
            else:
                return 'SEVERE'
        else:
            return 'OVER_AGE'
        
    def setTagColor(self, dateMeasured, score, table, row, column):
        if self.ageInMonths(dateMeasured) < 60:
            tag = self.getTag(dateMeasured, score)
            if tag == 'ABOVE_NORMAL':
                table.item(row, column).setBackground(COLOR_ORANGE)
            elif tag == 'NORMAL':
                table.item(row, column).setBackground(COLOR_GREEN)
            elif tag == 'BELOW_NORMAL':
                table.item(row, column).setBackground(COLOR_YELLOW)
            elif tag == 'SEVERE':
                table.item(row, column).setBackground(COLOR_RED)
        else:
            table.item(row, column).setBackground(COLOR_GRAY)

class Login(QDialog):
    def __init__(self):
        super(Login, self).__init__()
        loadUi("login.ui", self)
        self.setGeometry(0, 0, 450, 650)
        self.BtnLog.clicked.connect(self.proceed)
        self.BtnLog.setDefault(True)
        self.LogPassBox.setEchoMode(QtWidgets.QLineEdit.Password)
        self.BtnCreateacc.clicked.connect(self.createAccount)
        self.BtnViewprof.clicked.connect(self.viewprofile)
        self.initAccounts()
        
    def initAccounts(self):
        cursor.execute('SELECT COUNT(idBNS) as count FROM bns')
        bns = cursor.fetchone()
        if int(bns['count']) == 0:
            cursor.execute('INSERT INTO bns(firstName, lastName, email, password, isVerified) VALUES(%s, %s, %s, %s, %s)', ('System', 'Administrator', 'admin@localhost', '123456', '1'))
            conn.commit()

    #Disabling ESC keyevent
    def keyPressEvent(self, event):
        if itsOkToClose:
            super().reject()           

    def proceed(self):
        email = self.LogEmailBox.text()
        password = self.LogPassBox.text()

        if len(email) == 0 or len(password) == 0:
            msgBox('Warning', 'You must fill in all fields!', QtWidgets.QMessageBox().Warning)
        else:
            cursor.execute("SELECT * FROM bns WHERE email='{}'".format(email))
            result = cursor.fetchone()
            if cursor.rowcount > 0:
                if password == result.get('password'):
                    if result.get('isVerified') == 1:
                        global currentUser
                        currentUser = BNS(int(result.get('idBNS')))
                        widget.addWidget(mainWindow())
                        widget.setCurrentIndex(widget.currentIndex() + 1)
                        widget.setWindowTitle("{} - {}".format("Preschooler Profile", SYSTEM_NAME))
                        curResolution = QApplication.desktop()
                        screenGeo = curResolution.screenGeometry()
                        screenH = int(screenGeo.height())
                        screenW = int(screenGeo.width())
                        xAxis = (screenW / 2) - (1344 / 2)
                        yAxis = (screenH / 2) - (530 / 2)
                        widget.setGeometry(int(xAxis), int(yAxis), 1344, 530)
                    else:
                        msgBox('Login Failed', 'Your account is not validated!', QtWidgets.QMessageBox().Warning)                        
                else:
                    msgBox('Login Failed', 'Invalid Password', QtWidgets.QMessageBox().Warning)
            else:
                msgBox("Error", "User does not exist!", QtWidgets.QMessageBox().Warning)
                
    # From Login Menu going to Create Account
    def createAccount(self):
        widget.addWidget(CreateAcc())
        widget.setWindowTitle("{} - {}".format("Sign-up", SYSTEM_NAME))
        widget.setCurrentIndex(widget.currentIndex() + 1)
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (450 / 2)
        yAxis = (screenH / 2) - (550 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 450, 550)

    # From Login Menu going to Viewing of preschooler profile
    def viewprofile(self):
        widget.addWidget(Viewing())
        widget.setWindowTitle("{} - {}".format("Show Profile", SYSTEM_NAME))
        widget.setCurrentIndex(widget.currentIndex() + 1)
        #Centered Window upon Traverse
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (1288 / 2)
        yAxis = (screenH / 2) - (530 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 1288, 530)

class CreateAcc(QDialog):
    def __init__(self):
        super(CreateAcc, self).__init__()
        loadUi("CreateAccount.ui", self)
        self.signupPass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.signupConPass.setEchoMode(QtWidgets.QLineEdit.Password)
        self.BtnSignup.clicked.connect(self.addBNS)
        self.signupBack.clicked.connect(self.gotoLogin)

        #Set QlineEdit to Characters Only
        self.signupName.setValidator(validator)
        self.signupSur.setValidator(validator)

    #Disabling ESC keyevent
    def keyPressEvent(self, event):
        if itsOkToClose:
            super().reject()  

    def addBNS(self):
        bnsName = self.signupName.text()
        bnsSurname = self.signupSur.text()
        bnsEmail = self.signupEmail.text()
        bnsPassword = self.signupPass.text()
        bnsConPass = self.signupConPass.text()

        cursor.execute("SELECT * FROM bns WHERE email='{}'".format(bnsEmail))

        if len(bnsName) == 0 or len(bnsSurname) == 0 or len(bnsEmail) == 0 or len(bnsPassword) == 0 or len(bnsConPass) == 0:
            msgBox("Error", "You must fill in all fields!", QtWidgets.QMessageBox().Warning)
        elif cursor.rowcount > 0:
            msgBox("Warning", "Email already Exist!", QtWidgets.QMessageBox().Warning)
        elif bnsPassword != bnsConPass:
            msgBox("Warning", "Password does not match", QtWidgets.QMessageBox().Warning)
        else:

            BNS.add({
                'firstName': bnsName,
                'lastName': bnsSurname,
                'email': bnsEmail,
                'password': bnsPassword,
                'isVerified': '0'
            })
            msgBox("Info", "Account Successfully Created", QtWidgets.QMessageBox().Information)
            widget.addWidget(Login())
            widget.setCurrentIndex(widget.currentIndex() + 1)
            widget.setWindowTitle("{} - {}".format("Login", SYSTEM_NAME))
            curResolution = QApplication.desktop()
            screenGeo = curResolution.screenGeometry()
            screenH = int(screenGeo.height())
            screenW = int(screenGeo.width())
            xAxis = (screenW / 2) - (450 / 2)
            yAxis = (screenH / 2) - (650 / 2)
            widget.setGeometry(int(xAxis), int(yAxis), 450, 650)

    def gotoLogin(self):
        widget.addWidget(Login())
        widget.setCurrentIndex(widget.currentIndex() + 1)
        widget.setWindowTitle("{} - {}".format("Login Menu", SYSTEM_NAME))
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (450 / 2)
        yAxis = (screenH / 2) - (650 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 450, 650)

class UpdateProfile(QDialog):
    def __init__(self, id):
        super(UpdateProfile, self).__init__()
        loadUi("UpdateProfile.ui", self)
        
        self.btnClose.clicked.connect(self.cancelUpdate)
        self.btnUpdatePreschooler.clicked.connect(self.proceedUpdate)
        self.btnAddStatus.clicked.connect(self.addStatus)
        self.btnDeletestat.clicked.connect(self.deleteStatus)

        preschooler = Preschooler(id)
        self.preschoolerID = id
        self.firstName.setDisabled(True)
        self.lastName.setDisabled(True)
        self.birthdate.setDisabled(True)

        self.address.setText(preschooler.get('address'))
        self.firstName.setText(preschooler.firstName)
        self.lastName.setText(preschooler.lastName)
        self.guardianFName.setText(preschooler.get('guardianFName'))
        self.guardianLName.setText(preschooler.get('guardianLName'))
        self.birthdate.setDate(QtCore.QDate(preschooler.birthdate.year, preschooler.birthdate.month, preschooler.birthdate.day))

        viewModel = ['ID', 'DATE MEASURED', 'HEIGHT', 'WEIGHT']
        self.tableWidget.setColumnCount(len(viewModel))
        self.tableWidget.setHorizontalHeaderLabels(viewModel)
        self.tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.tableWidget.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)
        self.tableWidget.verticalHeader().setVisible(False)
        self.headers = self.tableWidget.horizontalHeader()
        self.headers.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)     
        self.headers.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)

        self.loadQuery = 'SELECT * FROM nutritionalstatus WHERE preschoolerID = ' + str(self.preschoolerID) + ' ORDER BY dateMeasured DESC'
        self.loadTable()
        self.setDefaults()

    def loadTable(self):
        cursor.execute(self.loadQuery)
        resultset = cursor.fetchall()

        for data in resultset:
            self.addToTable(data)

    def reloadTable(self):
        for i in range(self.tableWidget.rowCount()):
            self.tableWidget.removeRow(0)
            
        self.loadTable()

    def addToTable(self, data):
        rowPosition = self.tableWidget.rowCount()
        self.tableWidget.insertRow(rowPosition)
        self.tableWidget.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(data.get('idNutritionalStatus'))))
        self.tableWidget.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(data.get('dateMeasured'))))
        self.tableWidget.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(data.get('height'))))
        self.tableWidget.setItem(rowPosition, 3, QtWidgets.QTableWidgetItem(str(data.get('weight'))))

    def setDefaults(self):
        self.weight.setValue(0.0)
        self.height.setValue(45.0)
        self.dateMeasured.setDateTime(QtCore.QDateTime.currentDateTime())

    def addStatus(self):
        confirm = QtWidgets.QMessageBox()
        ans = confirm.question(self, "Confirmation", "Are you sure you want to add nutritional status?", confirm.Yes | confirm.No)
        if ans == confirm.Yes:
            Weight = self.weight.value()
            Height = self.height.value()
            preschoolerID = self.preschoolerID
            DMeasured = self.dateMeasured.date()
            DateMeasured = DMeasured.toPyDate()
            
            print('INSERT INTO nutritionalstatus(dateMeasured, weight, height, preschoolerID, encodedBy) VALUES({}, {}, {}, {}, {})'.format(DateMeasured.strftime('%Y-%m-%d'), str(Weight), str(Height), str(preschoolerID), str(currentUser.id)))
            addNutritionalStatusQuery = 'INSERT INTO nutritionalstatus(dateMeasured, weight, height, preschoolerID, encodedBy) VALUES(%s, %s, %s, %s, %s)'
            addNutritionalStatusValue = (DateMeasured.strftime('%Y-%m-%d'), str(Weight), str(Height), str(preschoolerID), str(currentUser.id))
            cursor.execute(addNutritionalStatusQuery, addNutritionalStatusValue)
            conn.commit()
            self.reloadTable()
            
            self.setDefaults()
        else:
            msgBox("NOTICE", "Add is Cancelled", QtWidgets.QMessageBox().Information)

    def deleteStatus(self):
        if self.tableWidget.rowCount() > 1:
            row = self.tableWidget.currentRow()
            if row >= 0:
                confirm = QtWidgets.QMessageBox()
                ans = confirm.question(self, "Confirmation", "Are you Sure to delete the selected Nutrional Status?", confirm.Yes | confirm.No)
                if ans == confirm.Yes:
                    cursor.execute('DELETE FROM nutritionalstatus WHERE idNutritionalStatus=' + str(self.tableWidget.item(row, 0).text()))
                    conn.commit()
                    self.tableWidget.removeRow(row)
                else:
                    msgBox("NOTICE", "Delete is Cancelled", QtWidgets.QMessageBox().Information)
            else:
                msgBox('Warning', 'You must select an item!', QtWidgets.QMessageBox().Warning)
        else:
            msgBox('Warning', 'Table must not be empty!', QtWidgets.QMessageBox().Warning)

    def proceedUpdate(self):
        confirm = QtWidgets.QMessageBox()
        ans = confirm.question(self, "Confirmation", "Are you Sure to update the selected Preschooler?", confirm.Yes | confirm.No)
        if ans == confirm.Yes:
            cursor.execute('UPDATE preschooler SET guardianFName=\'' + self.guardianFName.text() + '\', guardianLName=\'' + self.guardianLName.text() + '\', address=\'' + self.address.text() + '\' WHERE idPreschooler=' + str(self.preschoolerID))
            conn.commit()
            msgBox('Success', 'Updated success!', QtWidgets.QMessageBox().Information)
        else:
            msgBox("NOTICE", "Update is Cancelled", QtWidgets.QMessageBox().Information)
            
    def cancelUpdate(self):
        widget.addWidget(mainWindow())
        widget.setCurrentIndex(widget.currentIndex() + 1)
        widget.setWindowTitle("{} - {}".format("Main", SYSTEM_NAME))
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (1344 / 2)
        yAxis = (screenH / 2) - (530 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 1344, 530)


class Viewing(QDialog):
    def __init__(self):
        super(Viewing, self).__init__()
        loadUi("Viewing.ui", self)
        self.viewSort.activated.connect(self.sort)
        self.viewBack.clicked.connect(self.gotoLogin)
        self.viewSearch.textEdited.connect(self.search)

        viewModel = ['ID', 'CHILD NAME', 'CHILD SURNAME', 'GENDER', 'AGE IN MONTHS', 'WFA STATUS', 'HFA STATUS', 'WHFA STATUS']
        self.preInfoView.setColumnCount(len(viewModel))
        self.preInfoView.setHorizontalHeaderLabels(viewModel)
        self.preInfoView.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.preInfoView.setSelectionMode(False)
        self.preInfoView.verticalHeader().setVisible(False)
        self.headers = self.preInfoView.horizontalHeader()
        self.headers.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)     
        self.headers.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)
        self.preInfoView.setColumnWidth(5, 100)
        self.preInfoView.setColumnWidth(6, 100)
        self.preInfoView.setColumnWidth(7, 100)


        #Set QlineEdit to characters only
        self.viewSearch.setValidator(validator)
        
        self.loadPreschoolerTable()

    def addToTable(self, id):
        rowPosition = self.preInfoView.rowCount()
        preschooler = Preschooler(int(id))
        self.preInfoView.insertRow(rowPosition)  # THIS VALUE IS BASE ON TEXT BOX
        self.preInfoView.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(preschooler.id)))
        self.preInfoView.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(preschooler.firstName)))
        self.preInfoView.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(preschooler.lastName)))
        self.preInfoView.setItem(rowPosition, 3, QtWidgets.QTableWidgetItem(str(preschooler.gender)))

        cursor.execute('SELECT dateMeasured, height, weight FROM nutritionalstatus WHERE preschoolerID=\'' + str(preschooler.id) + '\' ORDER BY dateMeasured DESC LIMIT 1')
        if cursor.rowcount > 0:
            nutritionalStatus = cursor.fetchone()
            ageInMonths = preschooler.ageInMonths(nutritionalStatus.get('dateMeasured'))
            self.preInfoView.setItem(rowPosition, 4, QtWidgets.QTableWidgetItem(str(ageInMonths)))

            wfa, hfa, whfa = preschooler.calculate(nutritionalStatus)
            self.preInfoView.setItem(rowPosition, 5, QtWidgets.QTableWidgetItem(str(wfa)))
            self.preInfoView.setItem(rowPosition, 6, QtWidgets.QTableWidgetItem(str(hfa)))
            self.preInfoView.setItem(rowPosition, 7, QtWidgets.QTableWidgetItem(str(whfa)))
            
            preschooler.setTagColor(nutritionalStatus.get('dateMeasured'), wfa, self.preInfoView, rowPosition, 5)
            preschooler.setTagColor(nutritionalStatus.get('dateMeasured'), hfa, self.preInfoView, rowPosition, 6)
            preschooler.setTagColor(nutritionalStatus.get('dateMeasured'), whfa, self.preInfoView, rowPosition, 7)

    def sort(self):
        query = 'SELECT idPreschooler FROM preschooler'
        if self.viewSort.currentIndex() == 1:
            query = 'SELECT idPreschooler FROM preschooler ORDER BY firstName ASC'
        elif self.viewSort.currentIndex() == 2:
            query = 'SELECT idPreschooler FROM preschooler ORDER BY gender DESC'
        self.reloadPreschoolerTable(query)

    def reloadPreschoolerTable(self, query = 'SELECT idPreschooler FROM preschooler'):
        for i in range(self.preInfoView.rowCount()):
            self.preInfoView.removeRow(0)

        self.loadPreschoolerTable(query)

    def loadPreschoolerTable(self, query = 'SELECT idPreschooler FROM preschooler'):
        cursor.execute(query)
        resultset = cursor.fetchall()
        for result in resultset:
            self.addToTable(result.get('idPreschooler'))

    def search(self):
        self.reloadPreschoolerTable('SELECT idPreschooler FROM preschooler WHERE lastName LIKE \'' + self.viewSearch.text() + '%\'')

    def gotoLogin(self):
        returnLogin = Login()
        widget.addWidget(returnLogin)
        widget.setCurrentIndex(widget.currentIndex() + 1)
        widget.setWindowTitle("{} - {}".format("Login", SYSTEM_NAME))
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (450 / 2)
        yAxis = (screenH / 2) - (650 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 450, 650)

     #Disabling ESC keyevent
    def keyPressEvent(self, event):
        if itsOkToClose:
            super().reject() 

class mainWindow(QMainWindow):
    def __init__(self):
        super(mainWindow, self).__init__()
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)
        loadUi("MainWindow.ui", self)
        self.btnUserInfo.clicked.connect(self.gotoUserprofile)
        self.btnLogout.clicked.connect(self.Logout)
        self.showUserName.setText("{} {}".format(currentUser.get('firstname'), currentUser.get('lastname')))
        self.btnRemove.clicked.connect(self.deleteBNS)
        self.btnDelete.clicked.connect(self.delete)
        self.btnUpdate.clicked.connect(self.update)
        self.btnAddPre.clicked.connect(self.add)
        self.dateMeasured.setDateTime(QtCore.QDateTime.currentDateTime())
        self.dateMeasured.setMaximumDate(QDate.currentDate())
        self.btnValidate.clicked.connect(self.validate)
        self.comboBox.activated.connect(self.sort)
        self.searchName.textEdited.connect(self.search)
        self.btnHistory.clicked.connect(self.barPlot)

        self.toProfile.clicked.connect(self.goToPreschoolerProfile)
        self.toOverall.clicked.connect(self.goToOverAll)
        self.toValidation.clicked.connect(self.goToBNSValidation)

        self.overallChart.setContentsMargins(0, 0, 0, 0)
        self.layoutLay = QtWidgets.QHBoxLayout(self.overallChart)
        self.layoutLay.setContentsMargins(0, 0, 0, 0)
        self.goToOverAll()

        # SET TABLE WIDGET COLUMN
        columnModel = ['ID', 'ADDRESS', 'GUARDIAN NAME', 'GUARDIAN SURNAME', 'CHILD NAME', 'CHILD SURNAME', 'DATE OF BIRTH',
                       'DATE MEASURED', 'GENDER', 'WEIGHT', 'HEIGHT', 'AGE IN MONTHS', 'WFA STATUS', 'HFA STATUS', 'WHFA STATUS']
        self.preInfoTable.setColumnCount(len(columnModel))
        self.preInfoTable.setHorizontalHeaderLabels(columnModel)
        self.preInfoTable.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.preInfoTable.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)
        header = self.preInfoTable.horizontalHeader()
        header.setDisabled(True)
        self.preInfoTable.verticalHeader().setVisible(False)
        self.loadPreschoolerTable()

        self.headers = self.preInfoTable.horizontalHeader()
        self.headers.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents) 
        self.preInfoTable.setColumnWidth(1, 145)    
        self.headers.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(5, QtWidgets.QHeaderView.Stretch)     
        self.headers.setSectionResizeMode(6, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(7, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(8, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(9, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(10, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(11, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(12, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(13, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(14, QtWidgets.QHeaderView.Stretch)

        #Validated and Validation List
        validModel = ['ID', 'FIRST NAME', 'LAST NAME', 'EMAIL']
        self.validatedList.setColumnCount(len(validModel))
        self.validatedList.setHorizontalHeaderLabels(validModel)
        self.validatedList.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.validatedList.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)
        self.validatedList.horizontalHeader().setDisabled(True)
        self.headers = self.validatedList.horizontalHeader()
        self.headers.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)     
        self.headers.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.validatedList.verticalHeader().setVisible(False)

        self.validationList.setColumnCount(len(validModel))
        self.validationList.setHorizontalHeaderLabels(validModel)
        self.validationList.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.validationList.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)
        self.validationList.horizontalHeader().setDisabled(True)
        self.headers = self.validationList.horizontalHeader()
        self.headers.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)     
        self.headers.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.validationList.verticalHeader().setVisible(False)

        #Set Qlineedit to characters only
        self.searchName.setValidator(validator)
        self.preName.setValidator(validator)
        self.preSurname.setValidator(validator)
        self.preGuardName.setValidator(validator)
        self.preGuardSurname.setValidator(validator)

    def reloadPreschoolerTable(self, query = 'SELECT idPreschooler FROM preschooler'):
        for i in range(self.preInfoTable.rowCount()):
            self.preInfoTable.removeRow(0)

        self.loadPreschoolerTable(query)

    def loadPreschoolerTable(self, query = 'SELECT idPreschooler FROM preschooler'):
        cursor.execute(query)
        resultset = cursor.fetchall()
        for result in resultset:
            self.addToTable(result.get('idPreschooler'))

    def getData(self):
        data = {'totalPreschooler': 0, 'ABOVE_NORMAL': 0, 'NORMAL': 0, 'BELOW_NORMAL': 0, 'SEVERE': 0, 'OVER_AGE': 0}
        cursor.execute('SELECT idPreschooler FROM preschooler')

        if cursor.rowcount > 0:
            resultset = cursor.fetchall()
            for result in resultset:
                preschooler = Preschooler(int(result.get('idPreschooler')))
                data['totalPreschooler'] += 1

                cursor.execute('SELECT dateMeasured, height, weight FROM nutritionalstatus WHERE preschoolerID=\'' + str(preschooler.id) + '\' ORDER BY dateMeasured DESC LIMIT 1')
                if cursor.rowcount > 0:
                    nutritionalStatus = cursor.fetchone()
                    
                    whfa = preschooler.calculate(nutritionalStatus)[2]
                    data[preschooler.getTag(nutritionalStatus.get('dateMeasured'), whfa)] += 1
        return data

    def piePlot(self):
        pieSeries = QPieSeries()
        pieSeries.append("Severe(Severely Wasted)", self.getData().get('SEVERE'))
        pieSeries.append("Below Normal(Wasted)", self.getData().get('BELOW_NORMAL'))
        pieSeries.append("Normal", self.getData().get('NORMAL'))
        pieSeries.append("Above Normal(Overweight & Obese)", self.getData().get('ABOVE_NORMAL'))

        pieSlice = pieSeries.slices()[0]
        pieSlice.setPen(QtGui.QPen(QtGui.QColor(238, 29, 35), 1))
        pieSlice.setBrush(QtGui.QColor(238, 29, 35))
        pieSlice1 = pieSeries.slices()[1]
        pieSlice1.setPen(QtGui.QPen(QtGui.QColor(245, 241, 1), 1))
        pieSlice1.setBrush(QtGui.QColor(245, 241, 1))
        pieSlice2 = pieSeries.slices()[2]
        pieSlice2.setExploded(True)
        pieSlice2.setLabelVisible(True)
        pieSlice2.setPen(QtGui.QPen(QtGui.QColor(0, 165, 79), 1))
        pieSlice2.setBrush(QtGui.QColor(0, 165, 79))
        pieSlice3 = pieSeries.slices()[3]
        pieSlice3.setPen(QtGui.QPen(QtGui.QColor(242, 98, 33), 1))
        pieSlice3.setBrush(QtGui.QColor(242, 98, 33))

        pieChart = QChart()
        pieChart.addSeries(pieSeries)
        pieChart.setAnimationOptions(QChart.SeriesAnimations)

        pieView = QChartView(pieChart)
        if self.layoutLay.count() > 0:
            for i in reversed(range(self.layoutLay.count())): 
                self.layoutLay.takeAt(i).widget()
        self.layoutLay.addWidget(pieView)

        self.totalNumber.setText(str(self.getData().get('totalPreschooler')))
        self.presObese.setText(str(self.getData().get('ABOVE_NORMAL')))
        self.presNormal.setText(str(self.getData().get('NORMAL')))
        self.presSevere.setText(str(self.getData().get('SEVERE')))
        self.presBelowNormal.setText(str(self.getData().get('BELOW_NORMAL')))

    def barPlot(self):
        row = self.preInfoTable.currentRow()
        if row >= 0:
            barplotDialog = barplotDlg(self)
            barplotDialog.setBar(int(self.preInfoTable.item(row, 0).text()))
            barplotDialog.exec()
        else:
            msgBox("Select Row", "You must select a row first!", QtWidgets.QMessageBox.Warning)

    def addToTable(self, id):
        rowPosition = self.preInfoTable.rowCount()
        preschooler = Preschooler(int(id))
        self.preInfoTable.insertRow(rowPosition)  # THIS VALUE IS BASE ON TEXT BOX
        self.preInfoTable.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(preschooler.id)))
        self.preInfoTable.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(preschooler.get('address'))))
        self.preInfoTable.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(preschooler.get('guardianFName'))))
        self.preInfoTable.setItem(rowPosition, 3, QtWidgets.QTableWidgetItem(str(preschooler.get('guardianLName'))))
        self.preInfoTable.setItem(rowPosition, 4, QtWidgets.QTableWidgetItem(str(preschooler.firstName)))
        self.preInfoTable.setItem(rowPosition, 5, QtWidgets.QTableWidgetItem(str(preschooler.lastName)))
        self.preInfoTable.setItem(rowPosition, 6, QtWidgets.QTableWidgetItem(str(preschooler.birthdate)))
        
        cursor.execute('SELECT dateMeasured, height, weight FROM nutritionalstatus WHERE preschoolerID=\'' + str(preschooler.id) + '\' ORDER BY dateMeasured DESC LIMIT 1')
        if cursor.rowcount > 0:
            nutritionalStatus = cursor.fetchone()
            ageInMonths = preschooler.ageInMonths(nutritionalStatus.get('dateMeasured'))
            self.preInfoTable.setItem(rowPosition, 7, QtWidgets.QTableWidgetItem(str(nutritionalStatus.get('dateMeasured'))))
            self.preInfoTable.setItem(rowPosition, 8, QtWidgets.QTableWidgetItem(str(preschooler.gender)))
            self.preInfoTable.setItem(rowPosition, 9, QtWidgets.QTableWidgetItem(str(nutritionalStatus.get('weight'))))
            self.preInfoTable.setItem(rowPosition, 10, QtWidgets.QTableWidgetItem(str(nutritionalStatus.get('height'))))
            self.preInfoTable.setItem(rowPosition, 11, QtWidgets.QTableWidgetItem(str(ageInMonths)))

            wfa, hfa, whfa = preschooler.calculate(nutritionalStatus)
            self.preInfoTable.setItem(rowPosition, 12, QtWidgets.QTableWidgetItem(str(wfa)))
            self.preInfoTable.setItem(rowPosition, 13, QtWidgets.QTableWidgetItem(str(hfa)))
            self.preInfoTable.setItem(rowPosition, 14, QtWidgets.QTableWidgetItem(str(whfa)))
        
            preschooler.setTagColor(nutritionalStatus.get('dateMeasured'), wfa, self.preInfoTable, rowPosition, 12)
            preschooler.setTagColor(nutritionalStatus.get('dateMeasured'), hfa, self.preInfoTable, rowPosition, 13)
            preschooler.setTagColor(nutritionalStatus.get('dateMeasured'), whfa, self.preInfoTable, rowPosition, 14)

    def setDefaults(self):
        self.preAddress.clear()
        self.preGuardName.clear()
        self.preGuardSurname.clear()
        self.preName.clear()
        self.preSurname.clear()
        self.preWeight.setValue(0.0)
        self.preHeight.setValue(45.0)
        self.comboGender.setCurrentIndex(0)
        self.dateMeasured.setDateTime(QtCore.QDateTime.currentDateTime())
        self.birthDate.setDate(QtCore.QDate(2000, 1, 1))

    def add(self):
        Address = self.preAddress.text()
        GuardName = self.preGuardName.text()
        GuardSurname = self.preGuardSurname.text()
        PresName = self.preName.text()
        PreSurname = self.preSurname.text()
        Bdate = self.birthDate.date()
        Birthdate = Bdate.toPyDate()
        DMeasured = self.dateMeasured.date()
        DateMeasured = DMeasured.toPyDate()
        Gender = self.comboGender.currentIndex()
        Weight = self.preWeight.value()
        Height = self.preHeight.value()

        Date_birth = datetime.datetime(int(Bdate.year()), int(Bdate.month()), int(Bdate.day()))
        Date_Measured = datetime.datetime(int(DMeasured.year()), int(DMeasured.month()), int(DMeasured.day()))

        cursor.execute('SELECT * FROM preschooler WHERE firstName=\'' + PresName + '\' AND lastName=\'' + PreSurname + '\'')

        if len(PresName) == 0 or len(PreSurname) == 0 or len(str(Gender)) == 0 or len(Address) == 0 or len(
                GuardName) == 0 or len(GuardSurname) == 0 or len(str(Height)) == 0 or len(str(Weight)) == 0:
            msgBox("Error", "You must fill in all fields!", QtWidgets.QMessageBox().Warning)
        elif cursor.rowcount > 0:
            msgBox("Error", "Preschooler already exist!", QtWidgets.QMessageBox().Warning)
        elif Date_birth >= Date_Measured:
            msgBox("Invalid Date","Birth Date is less than the Date Measured", QtWidgets.QMessageBox().Warning)
        else:
            confirm = QtWidgets.QMessageBox()
            ans = confirm.question(self, "Confirmation", "Are you sure to add this Preschooler?",
                                   confirm.Yes | confirm.No)
            if ans == confirm.Yes:
                try:
                    #add to sql
                    addPreschoolerQuery = 'INSERT INTO preschooler(firstName, lastName, gender, birthdate, guardianFName, guardianLName, address, encodedBy) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)'
                    addPreschoolerValues = (PresName, PreSurname, Genderx[Gender], Birthdate.strftime('%Y-%m-%d'), GuardName, GuardSurname, Address, str(currentUser.id))
                    cursor.execute(addPreschoolerQuery, addPreschoolerValues)
                    conn.commit()
                    preschoolerID = int(cursor.lastrowid)

                    addNutritionalStatusQuery = 'INSERT INTO nutritionalstatus(dateMeasured, weight, height, preschoolerID, encodedBy) VALUES(%s, %s, %s, %s, %s)'
                    addNutritionalStatusValue = (DateMeasured.strftime('%Y-%m-%d'), str(Weight), str(Height), str(preschoolerID), str(currentUser.id))
                    cursor.execute(addNutritionalStatusQuery, addNutritionalStatusValue)
                    conn.commit()
                except:
                    conn.rollback()

                self.addToTable(preschoolerID)

                self.setDefaults()
            
    def update(self):
        self.setDefaults()
        row = self.preInfoTable.currentRow()
        if row >= 0:
            widget.addWidget(UpdateProfile(int(self.preInfoTable.item(row, 0).text())))
            widget.setWindowTitle("{} - {}".format("Update Preschooler", SYSTEM_NAME))
            widget.setCurrentIndex(widget.currentIndex() + 1)
        else:
            msgBox("Select Row", "You must select a row first!", QtWidgets.QMessageBox.Warning)


    # DELETE PRESCHOOLER PROFILE
    def delete(self):
        self.setDefaults()
        row = self.preInfoTable.currentRow()
        if row >= 0:
            # Confirmation Process before Deleting
            confirm = QtWidgets.QMessageBox()
            ans = confirm.question(self, "Confirmation", "Are you Sure to delete the selected Preschooler?", confirm.Yes | confirm.No)
            if ans == confirm.Yes:
                cursor.execute('DELETE FROM preschooler WHERE idPreschooler=' + str(self.preInfoTable.item(row, 0).text()))
                conn.commit()
                cursor.execute('DELETE FROM nutritionalstatus WHERE preschoolerID=' + str(self.preInfoTable.item(row, 0).text()))
                conn.commit()
                self.preInfoTable.removeRow(row)
            else:
                confirm.information(self, "Info", "Deletion has been cancelled")
        else:
            msgBox("Select Row", "You must select a row first!", QtWidgets.QMessageBox.Warning)


    def sort(self):
        query = 'SELECT idPreschooler FROM preschooler'
        if self.comboBox.currentIndex() == 1:
            query = 'SELECT idPreschooler FROM preschooler ORDER BY firstName ASC'
        elif self.comboBox.currentIndex() == 2:
            query = 'SELECT idPreschooler FROM preschooler ORDER BY gender DESC'
        self.reloadPreschoolerTable(query)
            
    def search(self):
        self.reloadPreschoolerTable('SELECT idPreschooler FROM preschooler WHERE firstName LIKE \'' + self.searchName.text() + '%\' OR lastName LIKE \'' + self.searchName.text() + '%\'')

    def loadBNSTable(self):
        #LOAD VALIDATED LIST
        cursor.execute('SELECT * FROM bns WHERE isVerified=\'1\'')
        resultset = cursor.fetchall()
        for result in resultset:
            rowPosition = self.validatedList.rowCount()
            self.validatedList.insertRow(rowPosition)  # THIS VALUE IS BASE ON TEXT BOX
            self.validatedList.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(result.get('idBNS'))))
            self.validatedList.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(result.get('firstName'))))
            self.validatedList.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(result.get('lastName'))))
            self.validatedList.setItem(rowPosition, 3, QtWidgets.QTableWidgetItem(str(result.get('email'))))

        #LOAD VALIDATION LIST
        cursor.execute('SELECT * FROM bns WHERE isVerified=\'0\'')
        resultset = cursor.fetchall()
        for result in resultset:
            rowPosition = self.validationList.rowCount()
            self.validationList.insertRow(rowPosition)  # THIS VALUE IS BASE ON TEXT BOX
            self.validationList.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(result.get('idBNS'))))
            self.validationList.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(result.get('firstName'))))
            self.validationList.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(result.get('lastName'))))
            self.validationList.setItem(rowPosition, 3, QtWidgets.QTableWidgetItem(str(result.get('email'))))

    # VALIDATION Process
    def validate(self):
        index = self.validationList.currentRow()
        # Confirmation Process before Validating
        if self.validationList.rowCount() == 0:
            msgBox("Error", "The validation list is empty", QtWidgets.QMessageBox().Critical)
        elif index >= 0:
            confirm = QtWidgets.QMessageBox()
            ans = confirm.question(self, "Confirmation", "Are you Sure to Validate the selected user?",
                                   confirm.Yes | confirm.No)
            if ans == confirm.Yes:
                id = self.validationList.item(index, 0).text()
                firstName = self.validationList.item(index, 1).text()
                lastName = self.validationList.item(index, 2).text()
                email = self.validationList.item(index, 3).text()

                cursor.execute('UPDATE bns SET isVerified=1 WHERE idBNS='+id)
                conn.commit()

                lastIndexValidated = self.validatedList.rowCount()
                self.validatedList.insertRow(lastIndexValidated)  # THIS VALUE IS BASE ON TEXT BOX
                self.validatedList.setItem(lastIndexValidated, 0, QtWidgets.QTableWidgetItem(str(id)))
                self.validatedList.setItem(lastIndexValidated, 1, QtWidgets.QTableWidgetItem(str(firstName)))
                self.validatedList.setItem(lastIndexValidated, 2, QtWidgets.QTableWidgetItem(str(lastName)))
                self.validatedList.setItem(lastIndexValidated, 3, QtWidgets.QTableWidgetItem(str(email)))

                self.validationList.removeRow(index)
            else:
                confirm.information(self, '', "Validation has been cancelled")
        else:
            msgBox("Select User", "You must select a user first!", QtWidgets.QMessageBox.Warning)
            
    def deleteBNS(self):
        index = self.validatedList.currentRow()
        if index >= 0:
            # Confirmation Process before Deleting
            confirm = QtWidgets.QMessageBox()
            ans = confirm.question(self, "NOTICE", "Are you sure to delete the selected user?", confirm.Yes | confirm.No)
            if ans == confirm.Yes:
                if self.validatedList.rowCount() == 1:
                    msgBox("Error", "Sorry You cant deleted this user!", QtWidgets.QMessageBox().Warning)
                elif self.validatedList.item(index, 0) == str(currentUser.id):
                    msgBox("Error", "Sorry You cant delete this user!", QtWidgets.QMessageBox().Warning)
                else:
                    cursor.execute('DELETE FROM bns WHERE idBNS=' + self.validatedList.item(index, 0).text())
                    conn.commit()
                    self.validatedList.removeRow(index)
            else:
                confirm.information(self, "Info", "Deletion is cancelled")
        else:
            msgBox("Select User", "You must select a user first!", QtWidgets.QMessageBox.Warning)


    # From Preschooler Profile going to User Profile
    def gotoUserprofile(self):
        bnsProf = BNSprofile()
        widget.addWidget(bnsProf)
        widget.setCurrentIndex(widget.currentIndex() + 1)
        widget.setWindowTitle("{} - {}".format("BNS Profile", SYSTEM_NAME))
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (455 / 2)
        yAxis = (screenH / 2) - (600 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 455, 600)
        
    def goToBNSValidation(self):
        self.stackedWidget.setCurrentWidget(self.bnsValidation)
        for i in range(self.validationList.rowCount()):
            self.validationList.removeRow(0)
        for i in range(self.validatedList.rowCount()):
            self.validatedList.removeRow(0)
            
        self.loadBNSTable()
        self.setDefaults()

    def goToOverAll(self):
        self.stackedWidget.setCurrentWidget(self.presOverall)
        self.piePlot()

    def goToPreschoolerProfile(self):
        self.stackedWidget.setCurrentWidget(self.presProfile)
        self.reloadPreschoolerTable()

    # From Preschooler Profile goint to Login Menu
    def Logout(self):
        #Confirmation Process before logout
        confirm = QtWidgets.QMessageBox()
        ans = confirm.question(self, "NOTICE", "Are you sure you want to Logout?", confirm.Yes | confirm.No)
        if ans == confirm.Yes:
            global currentUser
            currentUser = None
            widget.addWidget(Login())
            widget.setCurrentIndex(widget.currentIndex() + 1)
            widget.setWindowTitle("{} - {}".format("Login", SYSTEM_NAME))
            curResolution = QApplication.desktop()
            screenGeo = curResolution.screenGeometry()
            screenH = int(screenGeo.height())
            screenW = int(screenGeo.width())
            xAxis = (screenW / 2) - (450 / 2)
            yAxis = (screenH / 2) - (650 / 2)
            widget.setGeometry(int(xAxis), int(yAxis), 450, 650)

class BNSprofile(QDialog):
    def __init__(self):
        super(BNSprofile, self).__init__()
        loadUi("BNSprofile.ui", self)
        self.btnBack.clicked.connect(self.goBack)
        self.currentName.setDisabled(True)
        self.currentName.setText(currentUser.get('firstName'))
        self.currentSurname.setDisabled(True)
        self.currentSurname.setText(currentUser.get('lastName'))
        self.currentEmail.setDisabled(True)
        self.currentEmail.setText(currentUser.get('email'))
        self.btnChangePassword.clicked.connect(self.changePassword)
        self.btnClear.clicked.connect(self.clearText)

    #Disabling ESC keyevent
    def keyPressEvent(self, event):
        if itsOkToClose:
            super().reject()

    def clearText(self):
        self.oldPassword.clear()
        self.newPassword.clear()
        self.newPasswordCon.clear()

    def changePassword(self):
        if self.oldPassword.text() != currentUser.get('password'):
            msgBox("Error", "Old password does not match", QtWidgets.QMessageBox().Warning)
        elif self.oldPassword.text() == self.newPassword.text():
            msgBox("Error", "Old password and New password is the same!", QtWidgets.QMessageBox().Warning)
        elif self.newPassword.text() == self.newPasswordCon.text():
            global currentUSer
            cursor.execute('UPDATE bns SET password=\'' + self.newPassword.text() + '\' WHERE idBNS=' + str(currentUser.id))
            conn.commit()
            msgBox("Info", "Password has been changed Successfully", QtWidgets.QMessageBox().Information)
            self.oldPassword.clear()
            self.newPassword.clear()
            self.newPasswordCon.clear()
        else:
            msgBox("Error", "New password does not match!", QtWidgets.QMessageBox().Warning)

    # From User Profile going to Preschooler Profile
    def goBack(self):
        logSuccess = mainWindow()
        widget.addWidget(logSuccess)
        widget.setCurrentIndex(widget.currentIndex() + 1)
        widget.setWindowTitle("{} - {}".format("Main", SYSTEM_NAME))
        curResolution = QApplication.desktop()
        screenGeo = curResolution.screenGeometry()
        screenH = int(screenGeo.height())
        screenW = int(screenGeo.width())
        xAxis = (screenW / 2) - (1344 / 2)
        yAxis = (screenH / 2) - (530 / 2)
        widget.setGeometry(int(xAxis), int(yAxis), 1344, 530)

class barplotDlg(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        # Load the dialog's GUI
        loadUi("barPlot.ui", self)

    def setBar(self, preschoolerID):
        preschooler = Preschooler(int(preschoolerID))
        cursor.execute('SELECT dateMeasured, height, weight FROM nutritionalstatus WHERE preschoolerID=\'' + str(preschooler.id) + '\' ORDER BY dateMeasured DESC LIMIT 1')
        nutritionalStatus = cursor.fetchone()
        ageInMonths = preschooler.ageInMonths(nutritionalStatus.get('dateMeasured'))
        
        self.preschoolerName.setText(preschooler.firstName + ' ' + preschooler.lastName)
        self.preschoolerAge.setText(str(ageInMonths))

        #Setting up Bar Chart
        self.setFixedSize(QSize(750, 450))
        self.setWindowTitle("Preschooler History")
        self.closeBtn.clicked.connect(self.closeDlg)
        
        cursor.execute('SELECT weight, height, dateMeasured FROM nutritionalstatus WHERE preschoolerID=\'' + str(preschooler.id) + '\' ORDER BY dateMeasured ASC')
        resultset = cursor.fetchall()

        graphData, axis = [], 10

        for result in resultset:
            graphData.append({'axis': axis, 'whfa': preschooler.calculate(result)[2], 'ageInMonths': preschooler.ageInMonths(result.get('dateMeasured')), 'year': result.get('dateMeasured').year})
            axis += 10

        lineSeries = QLineSeries()
        QPoints = []
        for data in graphData:
            if data.get('ageInMonths') < 60:
                QPoints.append(QPoint(int(data.get('axis')), int(data.get('whfa'))))
                
        lineSeries.append(QPoints)
        lineSeries.setPointsVisible(True)

        # creating chart object
        chart = QChart()
        chart.legend().hide()
        chart.addSeries(lineSeries)
        pen = QtGui.QPen(QtGui.QColor(255, 109, 120))
        pen.setWidth(5)
        lineSeries.setPen(pen)

        font = QtGui.QFont('Open Sans')
        font.setPixelSize(20)
        chart.setTitleFont(font)
        chart.setTitleBrush(QtGui.QColor(0, 94, 125))
        chart.setTitle('Nutritional Status History')

        # customize axis
        axisX = QCategoryAxis()
        axisY = QCategoryAxis()

        labelFont = QtGui.QFont('Open Sans')
        labelFont.setPixelSize(13)

        axisX.setLabelsFont(labelFont)
        axisY.setLabelsFont(labelFont)

        axisPen = QtGui.QPen(QtGui.QColor(0, 94, 125))
        axisPen.setWidth(2)

        axisX.setLinePen(axisPen)
        axisY.setLinePen(axisPen)   

        axisBrush = QtGui.QBrush(QtGui.QColor(0, 94, 125))
        axisX.setLabelsBrush(axisBrush)
        axisY.setLabelsBrush(axisBrush)

        axisX.setRange(0, axis)
        
        for data in graphData:
            axisX.append(str(data.get('year')), data.get('axis'))

        axisY.setRange(-7, 7)
        axisY.append('Severe', -4)
        axisY.append('Below Normal', -2)
        axisY.append('Normal', 0)
        axisY.append('Above Normal', 2)
        axisY.append('Obese', 4)
        axisY.setLabelsVisible(True)
        
        axisX.setGridLineVisible(True)
        axisY.setGridLineVisible(True)
        axisX.setLabelsPosition(QCategoryAxis.AxisLabelsPositionOnValue)
        axisY.setLabelsPosition(QCategoryAxis.AxisLabelsPositionOnValue)

        chart.addAxis(axisX, Qt.AlignBottom)
        chart.addAxis(axisY, Qt.AlignLeft)

        lineSeries.attachAxis(axisX)
        lineSeries.attachAxis(axisY)

        lineView = QChartView(chart)
        lineView.setRenderHint(QtGui.QPainter.Antialiasing)
        lay1 = QtWidgets.QHBoxLayout(self.lineChart)
        lay1.setContentsMargins(0, 0, 0, 0)
        lay1.addWidget(lineView)

        columnModel = ['YEAR', 'AGE', 'WHFA']
        self.tableWidget.setColumnCount(len(columnModel))
        self.tableWidget.setHorizontalHeaderLabels(columnModel)
        self.tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.tableWidget.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)
        self.tableWidget.horizontalHeader().setDisabled(True)
        self.headers = self.tableWidget.horizontalHeader()
        self.headers.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)     
        self.headers.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.headers.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.tableWidget.verticalHeader().setVisible(False)

        cursor.execute('SELECT weight, height, dateMeasured FROM nutritionalstatus WHERE preschoolerID=\'' + str(preschooler.id) + '\' ORDER BY dateMeasured DESC')
        resultset = cursor.fetchall()

        for result in resultset:
            whfa = preschooler.calculate(result)[2]
            rowPosition = self.tableWidget.rowCount()
            self.tableWidget.insertRow(rowPosition)
            self.tableWidget.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(result.get('dateMeasured').year)))
            self.tableWidget.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(preschooler.ageInMonths(result.get('dateMeasured')))))
            self.tableWidget.setItem(rowPosition, 2, QtWidgets.QTableWidgetItem(str(whfa)))

    def closeDlg(self):
        self.accept()

class Widget(QStackedWidget):
    def closeEvent(self, event):
        reply = QMessageBox.question(
            self, "Message",
            "Are you sure you want to quit?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No)

        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()

app = QApplication(sys.argv)
mainwindow = Login()
widget = Widget()
widget.setWindowTitle("{} - {}".format("Login", SYSTEM_NAME))
widget.addWidget(mainwindow)
curResolution = QApplication.desktop()
screenGeo = curResolution.screenGeometry()
screenH = int(screenGeo.height())
screenW = int(screenGeo.width())
xAxis = (screenW / 2) - (450 / 2)
yAxis = (screenH / 2) - (650 / 2)
widget.setGeometry(int(xAxis), int(yAxis), 450, 650)
widget.show()
app.exec_()